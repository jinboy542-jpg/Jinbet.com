import React, {useMemo, useState} from "react";
import {createRoot} from "react-dom/client";
import "./styles.css";

const matches = [
  {id:1, league:"Premier League", time:"15:00", home:"Arsenal", away:"Chelsea", odds:["1.78","3.65","4.55"]},
  {id:2, league:"Premier League", time:"17:30", home:"Liverpool", away:"Manchester City", odds:["2.10","3.40","3.10"]},
  {id:3, league:"La Liga", time:"19:00", home:"Barcelona", away:"Atletico Madrid", odds:["1.85","3.55","4.10"]},
  {id:4, league:"Serie A", time:"21:00", home:"Inter", away:"AC Milan", odds:["1.92","3.35","3.90"]}
];

function App(){
  const [page,setPage] = useState("home");
  const [sports,setSports] = useState("Football");
  const [slip,setSlip] = useState([]);
  const [user,setUser] = useState(null);
  const [auth,setAuth] = useState(false);
  const [admin,setAdmin] = useState(false);

  const addBet=(m,i)=>{
    const label=[m.home,m.away,"Draw"][i];
    setSlip(s=>[...s.filter(x=>x.matchId!==m.id),{matchId:m.id,label,match:`${m.home} vs ${m.away}`,odd:m.odds[i]}]);
  };
  const total=useMemo(()=>slip.reduce((a,b)=>a*Number(b.odd),1),[slip]);

  if(admin) return <Admin onBack={()=>setAdmin(false)}/>;

  return <div className="app">
    <header className="top">
      <div className="brand" onClick={()=>setPage("home")}><span className="mark">J</span> Jin<span>Bet</span></div>
      <nav>
        <button onClick={()=>setPage("home")}>Home</button>
        <button onClick={()=>setPage("sports")}>Sports</button>
        <button onClick={()=>setPage("wallet")}>Wallet</button>
        <button onClick={()=>setPage("bets")}>My Bets</button>
      </nav>
      <div className="actions">
        {user ? <button className="userpill">{user}</button> :
          <button className="primary" onClick={()=>setAuth(true)}>Login / Register</button>}
        <button className="slipbtn" onClick={()=>setPage("slip")}>Bet Slip <b>{slip.length}</b></button>
      </div>
    </header>

    {page==="home" && <Home go={setPage}/>}
    {page==="sports" && <Sports addBet={addBet}/>}
    {page==="wallet" && <Wallet user={user} login={()=>setAuth(true)}/>}
    {page==="bets" && <MyBets user={user} login={()=>setAuth(true)}/>}
    {page==="slip" && <BetSlip slip={slip} total={total} remove={id=>setSlip(s=>s.filter(x=>x.matchId!==id))} login={()=>setAuth(true)} user={user}/>}
    <footer><div><b>JinBet</b> — Predict. Compete. Enjoy.</div><div>18+ • Play responsibly • Demo interface</div><button onClick={()=>setAdmin(true)}>Admin</button></footer>

    {auth && <Auth close={()=>setAuth(false)} onLogin={(name)=>{setUser(name);setAuth(false)}}/>}
  </div>
}

function Home({go}){
 return <main>
   <section className="hero">
    <div><div className="eyebrow">JINBET SPORTS</div><h1>Bet smarter.<br/><span>Play responsibly.</span></h1><p>Modern sports betting experience for football fans. Fast interface, clear odds and a simple bet slip.</p>
    <div className="heroBtns"><button className="primary big" onClick={()=>go("sports")}>Explore Sports</button><button className="ghost big" onClick={()=>go("wallet")}>Open Wallet</button></div></div>
    <div className="heroCard"><div className="live">● LIVE INTERFACE</div><h3>Football</h3><div className="miniMatch"><b>Arsenal</b><span>15:00</span><b>Chelsea</b></div><div className="oddsRow"><i>1.78</i><i>3.65</i><i>4.55</i></div><div className="balance">Demo balance <strong>KSh 1,000</strong></div></div>
   </section>
   <section className="section"><div className="sectionTitle"><h2>Popular sports</h2><button onClick={()=>go("sports")}>View all →</button></div><div className="cards">{["⚽ Football","🏀 Basketball","🎾 Tennis","🏎️ Motorsports"].map(x=><div className="sportCard" key={x} onClick={()=>go("sports")}><span>{x}</span><small>Markets available</small></div>)}</div></section>
   <section className="trust"><div><b>Secure account</b><span>Designed for KYC-ready onboarding</span></div><div><b>Simple betting</b><span>Clear selections and bet slip</span></div><div><b>Responsible play</b><span>18+ controls and limits</span></div></section>
 </main>
}

function Sports({addBet}){
 return <main className="content"><div className="pageHead"><div><div className="eyebrow">SPORTSBOOK</div><h1>Sports & markets</h1><p>Demo odds only — connect licensed odds/data services before live operation.</p></div><div className="tabs">{["Football","Basketball","Tennis"].map(x=><button className={x==="Football"?"active":""} key={x}>{x}</button>)}</div></div>
 <div className="league">{matches.map(m=><div className="match" key={m.id}><div className="matchInfo"><small>{m.league} • Today</small><b>{m.time}</b><span>{m.home} <em>vs</em> {m.away}</span></div><div className="market"><button onClick={()=>addBet(m,0)}><small>1</small>{m.odds[0]}</button><button onClick={()=>addBet(m,1)}><small>X</small>{m.odds[1]}</button><button onClick={()=>addBet(m,2)}><small>2</small>{m.odds[2]}</button></div></div>)}</div></main>
}

function BetSlip({slip,total,remove,login,user}){
 const [stake,setStake]=useState(100);
 return <main className="content narrow"><div className="pageHead"><div className="eyebrow">YOUR SELECTIONS</div><h1>Bet Slip</h1></div>
 {slip.length===0?<div className="empty"><div>🎟️</div><h2>Your bet slip is empty</h2><p>Choose odds from the Sports page to add selections.</p></div>:
 <div className="slipPanel">{slip.map(x=><div className="slipItem" key={x.matchId}><div><b>{x.label}</b><small>{x.match}</small></div><strong>{x.odd}</strong><button onClick={()=>remove(x.matchId)}>×</button></div>)}<div className="summary"><span>Total odds</span><b>{total.toFixed(2)}</b></div><label>Stake (KSh)<input type="number" value={stake} min="1" onChange={e=>setStake(e.target.value)}/></label><div className="summary"><span>Potential return</span><b>KSh {(Number(stake)*total).toFixed(2)}</b></div><button className="primary wide" onClick={user?()=>alert("Demo: connect licensed betting wallet and backend to place real wagers."):login}>{user?"Place Bet (Demo)":"Login to Place Bet"}</button></div>}
 </main>
}

function Wallet({user,login}){return <main className="content narrow"><div className="eyebrow">WALLET</div><h1>Wallet</h1>{!user?<div className="empty"><h2>Login to access your wallet</h2><button className="primary" onClick={login}>Login / Register</button></div>:<><div className="walletHero"><small>Available balance</small><strong>KSh 1,000.00</strong><span>Demo balance</span></div><div className="walletActions"><button className="primary" onClick={()=>alert("Connect M-Pesa/payment provider after licensing and compliance setup.")}>Deposit</button><button className="ghost" onClick={()=>alert("Withdrawal flow requires verified KYC and a compliant payment integration.")}>Withdraw</button></div><div className="notice">Production checklist: KYC/age verification, payment provider integration, transaction ledger, AML controls and audit logging.</div></>}</main>}

function MyBets({user,login}){return <main className="content narrow"><div className="eyebrow">ACCOUNT</div><h1>My Bets</h1>{!user?<div className="empty"><h2>Login to view your betting history</h2><button className="primary" onClick={login}>Login / Register</button></div>:<div className="empty"><div>📊</div><h2>No bets yet</h2><p>Your settled and open bets will appear here.</p></div>}</main>}

function Auth({close,onLogin}){const [name,setName]=useState("");return <div className="modal"><div className="modalBox"><button className="close" onClick={close}>×</button><div className="eyebrow">JINBET ACCOUNT</div><h2>Login / Register</h2><p>Demo authentication UI. Connect a secure backend before production.</p><input placeholder="Full name / username" value={name} onChange={e=>setName(e.target.value)}/><input placeholder="Phone number" /><input placeholder="Password" type="password"/><button className="primary wide" onClick={()=>onLogin(name||"JinBet User")}>Continue</button><small>By continuing you confirm you are 18+ and agree to responsible-gambling rules.</small></div></div>}

function Admin({onBack}){return <main className="admin"><header><div className="brand"><span className="mark">J</span> Jin<span>Bet</span> <small>ADMIN</small></div><button className="ghost" onClick={onBack}>← Back to site</button></header><div className="adminGrid"><aside><b>Dashboard</b><span>Users</span><span>Transactions</span><span>Bets & settlements</span><span>Sports / odds</span><span>KYC & compliance</span><span>Responsible gambling</span><span>Audit logs</span><span>Settings</span></aside><section><div className="eyebrow">CEO / ADMIN</div><h1>JinBet Control Center</h1><div className="stats"><div><small>Registered users</small><b>0</b></div><div><small>Active bets</small><b>0</b></div><div><small>Demo turnover</small><b>KSh 0</b></div><div><small>Pending KYC</small><b>0</b></div></div><div className="adminCard"><h3>Production controls</h3><p>Connect your secure backend for authentication, KYC, wallet ledger, odds feed, settlement engine, payment reconciliation, fraud monitoring and regulatory audit logs.</p><button className="primary" onClick={()=>alert("Backend connection point ready.")}>Configure backend</button></div></section></div></main>
}

createRoot(document.getElementById("root")).render(<App/>);
