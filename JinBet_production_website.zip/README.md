# JinBet Production Website Starter

A Vite + React production-oriented frontend for JinBet.

## Included
- Responsive homepage
- Sportsbook / football market interface
- Bet slip and potential-return calculator
- Login / registration UI
- Wallet structure
- My Bets page
- CEO/Admin dashboard
- KYC, responsible-gambling and compliance placeholders
- Vercel-ready Vite build

## Run locally
```bash
npm install
npm run dev
```

## Build
```bash
npm run build
```

## Deploy to Vercel
Import this folder/repository into Vercel. Vercel detects Vite automatically.
Build command: `npm run build`
Output directory: `dist`

## Important
This package is a production-oriented FRONTEND STARTER, not a licensed real-money betting operation. The demo odds, authentication, wallet and bet placement are intentionally not connected to real money.

Before accepting real wagers in Kenya, JinBet needs the appropriate Gambling Regulatory Authority licensing and compliant backend/payment/odds/KYC/AML/responsible-gambling controls. Do not enable real-money betting until legal and regulatory requirements are satisfied.

Recommended production backend:
- PostgreSQL
- Node.js/NestJS or similar API
- Secure authentication/session management
- KYC/age verification
- Licensed odds/data provider
- Payment provider with reconciliation
- Immutable wallet/transaction ledger
- Bet creation + settlement engine
- Fraud/AML monitoring
- Responsible-gambling limits/self-exclusion
- Audit logs and admin role permissions
